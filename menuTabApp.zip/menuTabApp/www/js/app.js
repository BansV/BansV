angular.module('ionicApp', ['ionic','ionic.services','ionic.controllers','ionic.routes'])


// .controller('NavCtrl', function($scope, $ionicSideMenuDelegate) {
//   $scope.showMenu = function () {
//     $ionicSideMenuDelegate.toggleLeft();
//   };
//   $scope.showRightMenu = function () {
//     $ionicSideMenuDelegate.toggleRight();
//   };
// })
// .controller('HomeTabCtrl', function($scope) {
// }); 
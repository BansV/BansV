angular.module('ionic.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  $stateProvider
    .state('search', {
      url: '/search',
      templateUrl: 'templates/search.html'
    })
    .state('settings', {
      url: '/settings',
      templateUrl: 'templates/settings.html'
    })
     .state('login', {
      url: '/login',
      templateUrl: 'templates/login.html',
      controller: 'LoginCtrl'
  })
    .state('tabs', {
      url: "/tab",
      templateUrl: "templates/tabs.html"
    })
    .state('tabs.home', {
      url: "/home",
      views: {
        'home-tab': {
          templateUrl: "templates/home.html",
          controller: 'HomeTabCtrl'
        }
      }
    })
    .state('tabs.facts', {
      url: "/facts",
      views: {
        'home-tab': {
          templateUrl: "templates/facts.html"
        }
      }
    })
    .state('tabs.facts2', {
      url: "/facts2",
      views: {
        'home-tab': {
          templateUrl: "templates/facts2.html"
        }
      }
    })
    .state('tabs.park', {
      url: "/park",
      views: {
        'park-tab': {
          templateUrl: "templates/park.html"
        }
      }
    })
    .state('tabs.navstack', {
      url: "/navstack",
      views: {
        'park-tab': {
          templateUrl: "templates/nav-stack.html"
        }
      }
    })
    .state('tabs.signout', {
      url: "/signout",
      views: {
        'signout-tab': {
          templateUrl: "templates/signout.html"
        }
      }
    });


   $urlRouterProvider.otherwise("/login");

})
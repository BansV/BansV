angular.module('parkingApp.parkCtrl', [])
.controller('ParkCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
});
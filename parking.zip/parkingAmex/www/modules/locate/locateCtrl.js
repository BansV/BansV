angular.module('parkingApp.locateCtrl', [])

.controller('LocateCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
})
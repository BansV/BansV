angular.module('parkingApp', [])
.controller('HelpCtrl', function($scope) {
  
});